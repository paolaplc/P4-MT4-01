#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  8 15:58:07 2025

@author: MT4-01
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
import librosa
from scipy.fft import rfft, irfft
from scipy.signal import (
    resample_poly, spectrogram, stft, firwin, lfilter,
    sosfilt, sosfiltfilt, filtfilt,
    sosfreqz, group_delay, freqz, butter, bilinear, tf2sos,)

from scipy.fft import fft, fftfreq


import librosa.display


# ===============================
# Parameters and Configuration
# ===============================

audio_path = '/Users/paolapolanco/Desktop/drive-download-20220311T084344Z-001/DT2_Danish_Speech_L1_S6.wav'
noise_path = '/Users/paolapolanco/Desktop/scrambling/noise.wav'
output_dir = './outputs_fft'
os.makedirs(output_dir, exist_ok=True)


target_fs = 44100    
block_size = 1024  # FFT block size
target_snr_db = 20  #wanted  SNR
f_low, f_high = 300, 3400   
method = 'u'                # Scrambling method: 'u' for uniform, 'pr' for pseudo-random
pr_seed = 264               
k_uniform = 35      
zero_rest = True            
add_noise =True  

# Filter
bp_use_fir = False
bp_Ap, bp_As = 3, 24
bp_fir_length = 480


ch_use_fir = True
ch_pass = 3250         
ch_stop = 4000         
ch_Ap = 0.5            
ch_As = 35             
ch_fir_length = 480    


post_use_fir = False
post_pass, post_stop = 3400, 4000
post_Ap, post_As = 2, 40
post_fir_length = 480




# ===============================
# Filter Design 
# ===============================


def design_bilinear_bandpass(fs, f1, f2, order=6):
    b_digital, a_digital = butter(order, [f1, f2], btype='bandpass', fs=fs)
    return b_digital, a_digital


def design_bilinear_lowpass(fs, f_pass, f_stop=None, Ap=None, As=None, order=6, stage=2):
    b_digital, a_digital = butter(order, f_pass, btype='low', fs=fs)
    label = 'Channel' if stage == 2 else 'Post'
    print(f"[{label} IIR] Order {order}, Pass <= {f_pass} Hz")
    return b_digital, a_digital


def design_fir_lowpass(fs, f_pass, f_stop, numtaps):
    cutoff_candidates = np.linspace(f_pass + 50, f_stop + 300, 300)  
    best_cutoff = None
    best_taps = None
    min_error = float('inf')

    for cutoff in cutoff_candidates:
        taps = firwin(
            numtaps,
            cutoff=cutoff,
            fs=fs,
            window='hamming',
            pass_zero='lowpass',
            scale=True
        )
        w, h = freqz(taps, worN=2048, fs=fs)
        H_db = 20 * np.log10(np.abs(h) + 1e-10)

        db_3250 = np.interp(3250, w, H_db)
        db_3400 = np.interp(3400, w, H_db)
        db_4000 = np.interp(4000, w, H_db)

        error = (db_3400 + 3)**2  
        if db_3250 < -0.5:
            error += 1000  
        if db_4000 > -40:
            error += 1000  

        if error < min_error:
            min_error = error
            best_cutoff = cutoff
            best_taps = taps

    print(f"[FIR Lowpass] Cutoff {best_cutoff:.2f} Hz — Meets spec ✓")
    return best_taps



def design_fir_bandpass(fs, f_low, f_high, numtaps):
    nyq = fs / 2
    taps = firwin(numtaps, [f_low / nyq, f_high / nyq],
                  pass_zero=False, window='hamming')
    return taps




# ===============================
# Scrambling and Descrambling
# ===============================



def bandlimited_fft_scramble(x, N, fs,
                             f_low=300, f_high=3400,
                             method="pr", seed=42, k=7,
                             zero_rest=True):
    # Frame the signal (truncate so len(x) is an integer multiple of N)
    x = x[: len(x) - len(x) % N]
    frames = x.reshape(-1, N)          # (n_frames, N)

    # Forward real FFT (positive frequencies only)
    X = rfft(frames, axis=1)           # (n_frames, N//2+1)

    #telephone‑band bins
    bin_res   = fs / N
    print(f"bin res: {bin_res}")
    bin_start = int(np.ceil (f_low  / bin_res))
    print(f"start: {bin_start}")
    bin_end   = int(np.floor(f_high / bin_res)) + 1
    print(f"end: {bin_end}")
    band_bins = np.arange(bin_start, bin_end)
    print(len(band_bins))

    # Build permutation
    if method == "pr":
        perm = np.random.default_rng(seed).permutation(len(band_bins))
    elif method == "u":
        nB = len(band_bins)
        if np.gcd(k, nB) != 1:
            raise ValueError(f"k = {k} is not coprime with #band_bins = {nB}")
        perm = np.array([(k * r) % nB for r in range(nB)])
    else:
        raise ValueError("method must be 'pr' or 'u'")

    # Apply scrambling
    X_scr = np.zeros_like(X) if zero_rest else X.copy()
    X_scr[:, band_bins] = X[:, band_bins[perm]]

    # Inverse real FFT back to time domain
    return irfft(X_scr, n=N, axis=1).flatten(), perm, band_bins


def bandlimited_fft_descramble(x, N, fs, band_bins, perm, zero_rest=True):
    """Undo the scrambling performed by `bandlimited_fft_scramble`."""
    inv_perm = np.empty_like(perm)
    inv_perm[perm] = np.arange(len(perm))

    x = x[: len(x) - len(x) % N]
    frames = x.reshape(-1, N)

    X = rfft(frames, axis=1)
    X_des = np.zeros_like(X) if zero_rest else X.copy()
    X_des[:, band_bins] = X[:, band_bins[inv_perm]]

    return irfft(X_des, n=N, axis=1).flatten()






# ===============================
# Plotting Fuctions
# ===============================


def evaluate_snr(clean, proc, label):
    noise = clean[:len(proc)] - proc
    snr = 10 * np.log10(np.sum(clean[:len(proc)] ** 2) / np.sum(noise ** 2))
    print(f"[{label} SNR] {snr:.2f} dB")
    return snr
 
    
    
def plot_filter_response(coeffs, fs, fir=True, Ap=None, As=None, passband=None, stopband=None, label=""):
    from scipy.interpolate import interp1d

    # Frequency response
    if fir:
        w, h = freqz(coeffs, worN=2048, fs=fs)
    else:
        b, a = coeffs
        w, h = freqz(b, a, worN=2048, fs=fs)

    mag_db = 20 * np.log10(np.abs(h) + 1e-12)
    max_db = np.max(mag_db)
    cutoff_level = max_db - 3

    # Find -3 dB cutoff points
    crossings = np.where(np.diff(np.sign(mag_db - cutoff_level)))[0]
    cutoff_freqs = []
    for idx in crossings:
        # Linearly interpolate between points to find exact crossing
        f_interp = interp1d(mag_db[idx:idx + 2], w[idx:idx + 2])
        try:
            fc = f_interp(cutoff_level)
            cutoff_freqs.append(fc)
        except:
            pass  # Ignore edge cases if interpolation fails

    # Plot
    plt.figure(figsize=(10, 5))
    plt.plot(w, mag_db, label='Magnitude Response', linewidth=1.5)
    plt.title(f"{label} Filter Response")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Magnitude [dB]")
    plt.grid(True)
    plt.ylim([-100, 5])
    plt.xlim(0, 5000)

    # Passband edges
    if passband is not None:
        label_pass = 'Passband edge'
        if isinstance(passband, (tuple, list, np.ndarray)):
            for i, f in enumerate(passband):
                plt.axvline(f, color='green', linestyle='--', label=label_pass if i == 0 else "")
        else:
            plt.axvline(passband, color='green', linestyle='--', label='Passband edge')

    # Stopband edges
    if stopband is not None:
        label_stop = 'Stopband edge'
        if isinstance(stopband, (tuple, list, np.ndarray)):
            for i, f in enumerate(stopband):
                plt.axvline(f, color='red', linestyle='--', label=label_stop if i == 0 else "")
        else:
            plt.axvline(stopband, color='red', linestyle='--', label='Stopband edge')

    # Ripple/attenuation
    if Ap is not None:
        plt.axhline(-Ap, color='green', linestyle=':', label=f'Passband ripple ({Ap} dB)')
    if As is not None:
        plt.axhline(-As, color='red', linestyle=':', label=f'Stopband attenuation ({As} dB)')

    # Plot -3 dB cutoff markers
    for i, fc in enumerate(cutoff_freqs):
        plt.axvline(fc, color='orange', linestyle='-.', label='-3 dB cutoff system measurred' if i == 0 else "")

    plt.legend(loc='lower left')
    plt.tight_layout()
    plt.show()



def plot_signal_phase(sig, fs, title, f_max=5000):
    N = len(sig)
    freqs = fftfreq(N, 1/fs)
    SIG = fft(sig)
    phase = np.angle(SIG)

    # Only keep positive frequencies up to f_max
    pos_freqs = freqs[:N//2]
    pos_phase = phase[:N//2]

    mask = pos_freqs <= f_max

    plt.figure(figsize=(10, 4))
    plt.plot(pos_freqs[mask], pos_phase[mask])
    plt.title(f'Phase of signal after filtering: {title}')
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('Phase [radians]')
    plt.grid()
    plt.tight_layout()
    plt.show()




def plot_filter_phase(coeffs, fs, *, fir=True, label=""):
    """
    Phase response of an FIR tap vector  OR   an (b,a) IIR pair.
    """
    if fir:
        w, h = freqz(coeffs, worN=4096, fs=fs)
    else:
        b, a = coeffs
        w, h = freqz(b, a, worN=4096, fs=fs)

    phase = np.unwrap(np.angle(h))          # un-wrap
    plt.figure(figsize=(8, 4))
    plt.plot(w, phase, lw=1.5)
    plt.title(f"{label} – Phase response")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Phase [rad]")
    plt.grid(True)
    plt.xlim(0, 5000)                       
    plt.show()



def plot_stft_signals(signals, fs, labels=None, title_tag=""):
    num_signals = len(signals)
    if labels is None:
        labels = [f"Signal {i+1}" for i in range(num_signals)]

    fig, axs = plt.subplots(num_signals, 1, figsize=(10, 3 * num_signals))
    if num_signals == 1:
        axs = [axs]

    for idx, sig in enumerate(signals):
        D = librosa.stft(sig, n_fft=1024, hop_length=256, window='hann')
        S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)

        img = librosa.display.specshow(S_db, sr=fs, hop_length=256,
                                       x_axis='time', y_axis='hz',
                                       ax=axs[idx], cmap='viridis')
        axs[idx].set_title(labels[idx])
        axs[idx].set_ylim([0, 5000])

    fig.suptitle(title_tag, fontsize=14)
    fig.colorbar(img, ax=axs, format="%+2.0f dB")
    plt.tight_layout()
    plt.show()
    

def plot_spectrograms(signals, fs, labels=None, title_tag=""):
    num_signals = len(signals)

    if labels is None:
        labels = [f"Signal {i+1}" for i in range(num_signals)]
    elif len(labels) != num_signals:
        raise ValueError("Number of labels must match number of signals.")

    fig, axs = plt.subplots(1, num_signals, figsize=(5 * num_signals, 4))
    fig.suptitle(f"{title_tag}", fontsize=16)

    if num_signals == 1:
        axs = [axs]

    for idx, sig in enumerate(signals):
        f, t_spec, Sxx = spectrogram(sig, fs=fs, window="hamming", nperseg=512, noverlap=256)
        pcm = axs[idx].pcolormesh(t_spec, f, 10 * np.log10(Sxx + 1e-12), shading="gouraud")
        axs[idx].set_title(f"{labels[idx]}")
        axs[idx].set_xlabel("Time [s]")
        axs[idx].set_ylabel("Frequency [Hz]")
        axs[idx].set_ylim(0, 5000)

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.show()
    


    
# ===============================
# Main Processing Pipeline
# ===============================

def main():
    # ----------------------------------
    # 0) Initialise holders (avoid scope issues)
    # ----------------------------------
    taps1 = taps2 = None
    b = a = b2 = a2 = None

    # -----------------
    # 1) Audio
    # -----------------
    x, fs_in = sf.read(audio_path)
    x = x.flatten()
    print(f" Original sample rate: {fs_in} Hz, Target sample rate: {target_fs} Hz")
    if fs_in != target_fs:
        x = resample_poly(x, target_fs, fs_in)
        print("[Audio resampled.]")

    # -----------------
    # 2) Noise
    # -----------------
    n_raw, fs_n = librosa.load(noise_path, sr=None)
    if fs_n != target_fs:
        print(f"Noise resampled from {fs_n} Hz to {target_fs} Hz")
        n = resample_poly(n_raw, target_fs, fs_n)
    else:
        n = n_raw
    n = np.tile(n, int(np.ceil(len(x) / len(n))))[:len(x)]

    if add_noise:
        Ps, Pn = np.mean(x**2), np.mean(n**2)
        alpha = np.sqrt(Ps / (Pn * 10**(target_snr_db / 10)))
        mixed = x + alpha * n
        evaluate_snr(x, mixed, 'Mixed')
        sf.write(os.path.join(output_dir, 'mixed.wav'), mixed, target_fs)
        print(" Noise added — signal + noise")
    else:
        mixed = x.copy()
        print(" Noise not added — clean signal used.")

    # -----------------
    # 3) Band‑pass before scrambling
    # -----------------
    if bp_use_fir:
        taps1 = design_fir_bandpass(target_fs, f_low, f_high, bp_fir_length)
        x1 = lfilter(taps1, [1.0], mixed)
        plot_filter_response(taps1, fs=target_fs, fir=True,
                             Ap=bp_Ap, As=bp_As, passband=(f_low, f_high),
                             stopband=(f_low - 100, f_high + 100), label="FIR Bandpass")
        plot_filter_phase(taps1, target_fs, fir=True,  label="FIR Band-pass")   # ← add
    else:
        b, a = design_bilinear_bandpass(fs=target_fs, f1=f_low, f2=f_high, order=6)
        x1 = lfilter(b, a, mixed)
        plot_filter_response((b, a), fs=target_fs, fir=False,
                             Ap=bp_Ap, As=bp_As, passband=(f_low, f_high),
                             stopband=(f_low - 100, f_high + 100), label="IIR Bandpass")
        plot_filter_phase((b, a), target_fs, fir=False, label="IIR Band-pass")  # ← add

    sf.write(os.path.join(output_dir, 'stage1_bp.wav'), x1, target_fs)
    plot_spectrograms([x, mixed, x1], fs=target_fs,
                 labels=["Original", "Signal + Noise", "Bandpass signal"],
                 title_tag="(Stage 1)")
    

    # -----------------
    # 4) Scrambling
    # -----------------
    xs, perm, bins = bandlimited_fft_scramble(
        x1, block_size, target_fs, f_low, f_high,
        method, pr_seed, k_uniform, zero_rest
    )
    sf.write(os.path.join(output_dir, 'scrambled.wav'), xs, target_fs)


    # -----------------
    # 5) Channel Lowpass
    # -----------------
    if ch_use_fir:
        taps2 = design_fir_lowpass(target_fs, ch_pass, ch_stop, ch_fir_length)
        x2 = lfilter(taps2, [1.0], xs)
        #x2 = filtfilt(taps2, [1.0], xs) #non causal #zero phase
        plot_filter_response(taps2, fs=target_fs, fir=True,
                             Ap=ch_Ap, As=ch_As, passband=ch_pass,
                             stopband=ch_stop, label="Channel FIR Lowpass")

    else:
        b2, a2 = design_bilinear_lowpass(target_fs, ch_pass, ch_stop,
                                         Ap=ch_Ap, As=ch_As, stage=2, order=6)
        x2 = lfilter(b2, a2, xs)
        plot_filter_response((b2, a2), fs=target_fs, fir=False,
                             Ap=ch_Ap, As=ch_As, passband=ch_pass,
                             stopband=ch_stop, label="Channel IIR Lowpass")

    plot_signal_phase(x2, target_fs, 'After Channel Filtering')

    # -----------------
    # 6) Descrambling
    # -----------------
    xd = bandlimited_fft_descramble(x2, block_size, target_fs, bins, perm, zero_rest)
    sf.write(os.path.join(output_dir, 'descrambled.wav'), xd, target_fs)


    # -----------------
    # 7) Final Output
    # -----------------
    y = xd
    
    plot_spectrograms([xs, x2, xd], fs=target_fs,
                 labels=["Scrambled", "After Channel", "Descrambled"],
                 title_tag="(Stage 2)")
    

    # -----------------
    # 8) Encoding Delay Calculation
    # -----------------
    def gd_iir(b, a, band, fs, n_points=4096):
        sos = tf2sos(b, a)
        w_rad = 2 * np.pi * np.linspace(band[0], band[1], n_points) / fs
        _, h = sosfreqz(sos, worN=w_rad)
        phase = np.unwrap(np.angle(h))
        tau = -np.gradient(phase, w_rad)
        return float(np.mean(tau))

    def gd_fir(numtaps):
        return (numtaps - 1) / 2

    L_bp = gd_fir(len(taps1)) if bp_use_fir else gd_iir(b, a, (f_low, f_high), target_fs)
    #L_ch = 0 if ch_use_fir else gd_iir(b2, a2, (0, ch_pass), target_fs) #non causal
    L_ch = gd_fir(len(taps2)) if ch_use_fir else gd_iir(b2, a2, (0, ch_pass), target_fs)
    L_perm = block_size
    L_total = L_bp + L_ch + L_perm
    t_total = L_total / target_fs

    print("\n--- LATENCY BREAKDOWN ---")
    print(f"Bandpass Filter  : {L_bp:.2f} samples ({L_bp/target_fs*1e3:.2f} ms)")
    print(f"Channel Filter   : {L_ch:.2f} samples ({L_ch/target_fs*1e3:.2f} ms)")
    print(f"Permutation Delay: {L_perm} samples ({L_perm/target_fs*1e3:.2f} ms)")
    print(f"TOTAL LATENCY    : {L_total:.2f} samples ({t_total*1e3:.2f} ms)")
    print("=============================================")

    # -----------------
    # 9) Plots and Results
    # -----------------
    print("\nProcessing complete. Outputs saved to:", output_dir)

    plot_spectrograms([x1, xs, xd], fs=target_fs,
                 labels=["Signal", "Scrambled", "Descrambled"],
                 title_tag="Henning ser ni smukke planter N = 256")


# ===============================
# Entry Point
# ===============================
if __name__ == '__main__':
    main()
