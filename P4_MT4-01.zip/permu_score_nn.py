#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 11 14:57:30 2025

@author: MT4-01
"""


from __future__ import annotations
import numpy as np
from math import gcd
from typing import List, Tuple



# ========= user‑selectable parameters =========
BLOCK: int = 72   # permutation (block) size; 
SEED0: int = 42    # first RNG seed to use for the pseudo‑random list
# ==============================================



# ---------- hybrid_distance metric (vector only) -----------------

def hybrid_distance(perm: np.ndarray) -> int:
    """Hybrid distance on a permutation vector.

    HD(perm) = L¹ displacement  +  Σ(max(0, edge‑separation − 1))
    where edge‑separation looks at the positions of consecutive values.
    The identity permutation has distance 0.
    """
    n = len(perm)
    pos = np.empty(n, dtype=np.int32)
    pos[perm] = np.arange(n, dtype=np.int32)
    deviation: int = int(np.abs(perm - np.arange(n)).sum())
    separation: int = int(sum(abs(pos[v] - pos[v + 1]) - 1 for v in range(n - 1)))
    return deviation + separation



# ---------- generate permutations --------------------------------

def uniform_perm(N: int, k: int) -> np.ndarray:
    """Return the permutation r ↦ k·r (mod N) as a NumPy array."""
    return np.fromiter(((k * r) % N for r in range(N)), dtype=np.int32, count=N)


def random_perm(N: int, seed: int) -> np.ndarray:
    """Return a NumPy array containing a pseudorandom permutation."""
    return np.random.default_rng(seed).permutation(N).astype(np.int32)




# ---------- helper to pretty‑print a list -------------------------

def print_table(header: str, rows: List[Tuple[int, int]], label: str) -> None:
    print(header)
    print(f"{label}\tHybridDistance")
    for key, score in rows:
        print(f"{key}\t{score}")
    print()




# ---------- main --------------------------------------------------

def main(N: int, seed0: int = 0) -> None:
    coprimes: List[int] = [k for k in range(1, N) if gcd(k, N) == 1]
    num: int = len(coprimes)
    seeds: List[int] = list(range(seed0, seed0 + num))

    print(f"\n=== block size N = {N} (coprimes = {num}) ===\n")

    # ---- uniform list ----
    uniform_rows: List[Tuple[int, int]] = [
        (k, hybrid_distance(uniform_perm(N, k))) for k in coprimes
    ]
    print_table("Uniform permutations:", uniform_rows, "k")
    best_k, best_uniform = max(uniform_rows, key=lambda x: x[1])
    print(f"Highest uniform hybrid_distance: {best_uniform} (k = {best_k})\n")

    # ---- pseudo‑random list ----
    random_rows: List[Tuple[int, int]] = [
        (s, hybrid_distance(random_perm(N, s))) for s in seeds
    ]
    print_table("Pseudo‑random permutations:", random_rows, "Seed")
    best_seed, best_random = max(random_rows, key=lambda x: x[1])
    print(f"Highest pseudo‑random hybrid_distance: {best_random} (seed = {best_seed})\n")

    # ---- sanity check ----
    identity = np.arange(N, dtype=np.int32)
    print(f"Identity hybrid_distance: {hybrid_distance(identity)} (should be 0)")
    print("-" * 40)



if __name__ == "__main__":
    main(BLOCK, SEED0)
